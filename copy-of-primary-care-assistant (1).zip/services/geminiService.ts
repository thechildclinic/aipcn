
import { ChatMessage, ProvisionalDiagnosisResult, GeneratedQuestion, Medication, TestRecommendation, Prescription, PatientProfile, MetaSymptomQuestion, DoctorNoteSuggestion, DDxItem, DDxActionSuggestion } from '../types';

// IMPORTANT: If your backend is a separate Cloud Run service (likely),
// you MUST replace '/api' below with the FULL URL of your backend service.
// For example: const API_BASE_URL = 'https://your-backend-primary-care-api-xyz.a.run.app/api';
const API_BASE_URL = '/api'; // Assuming backend is served from the same origin or proxied
const DEFAULT_TIMEOUT = 60000; // 60 seconds

// Helper for API calls
async function fetchApi<T>(endpoint: string, body: unknown, method: string = 'POST', timeout: number = DEFAULT_TIMEOUT): Promise<T | null> {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeout);

  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      method: method,
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
      signal: controller.signal, // Pass the abort signal to fetch
    });

    clearTimeout(id); // Clear the timeout if the request completes in time

    if (!response.ok) {
      let errorData = { message: `Request failed with status ${response.status}` };
      let responseText = '';
      try {
        responseText = await response.text();
        errorData = JSON.parse(responseText); 
      } catch (e) {
        console.warn(`Could not parse error response from ${endpoint} as JSON. Response text: ${responseText}`);
        if (responseText) { 
            errorData.message = responseText.substring(0, 300); 
        }
      }
      console.error(`API Error (${response.status}) calling ${endpoint}:`, errorData.message || response.statusText, 'Full Response Text (if any):', responseText);
      return null;
    }
    
    if (endpoint === '/symptom-checker/doctor-notes') { 
        const textResponse = await response.text();
        return textResponse as T; 
    }
    return await response.json() as T;
  } catch (error: any) {
    clearTimeout(id); // Ensure timeout is cleared on error too
    if (error.name === 'AbortError') {
      console.error(`API call to ${endpoint} timed out after ${timeout/1000} seconds.`);
      // alert(`The request to the server timed out. Please check your connection or try again later.`);
    } else {
      console.error(`Network or other critical error calling ${endpoint}:`, error);
    }
    return null;
  }
}


export const getInitialAssessmentAndQuestion = async (symptoms: string, chatHistory: ChatMessage[], patientProfile?: PatientProfile): Promise<GeneratedQuestion | null> => {
  const result = await fetchApi<GeneratedQuestion>('/symptom-checker/initial-assessment', { symptoms, chatHistory, patientProfile });
  // This fallback triggers if fetchApi returns null
  return result || { question: "I'm having a little trouble understanding that right now. Could you please try rephrasing, or we can try again in a moment?" };
};

export const getProvisionalDiagnosis = async (chatHistory: ChatMessage[], patientProfile?: PatientProfile): Promise<ProvisionalDiagnosisResult | null> => {
  const result = await fetchApi<ProvisionalDiagnosisResult>('/symptom-checker/provisional-diagnosis', { chatHistory, patientProfile });
  return result || { condition: null, confidence: 'error', summaryForPatient: "I encountered an issue trying to process the assessment. It would be best to discuss your symptoms directly with a healthcare provider.", nextSteps: "Please try finding a clinic or try the assessment again later." };
};

export const suggestTestsBasedOnCondition = async (provisionalCondition: string): Promise<string[] | null> => {
  // Assuming this returns an array of strings or null on error
  const result = await fetchApi<string[]>('/symptom-checker/suggest-tests', { provisionalCondition });
  return result || []; // Fallback to empty array if API fails
};

export const refineDiagnosisWithTestResults = async (provisionalDiagnosis: string, testResultsSummary: string, patientProfile?: PatientProfile): Promise<ProvisionalDiagnosisResult | null> => {
  const result = await fetchApi<ProvisionalDiagnosisResult>('/symptom-checker/refine-diagnosis', { provisionalDiagnosis, testResultsSummary, patientProfile });
  if (result) return result;
  // Fallback if API fails or returns null structure for some reason
  return { 
    condition: provisionalDiagnosis, // Keep original diagnosis
    confidence: 'unchanged', // Indicate no change from AI due to error
    summaryForPatient: "Thank you for uploading your test results. While I had trouble processing them with AI assistance, your doctor will review them carefully.", 
    nextSteps: "Please ensure your doctor reviews these results during your consultation." 
  };
};

export const generateDoctorNotes = async (symptoms: string, provisionalDiagnosis: string, patientProfile?: PatientProfile, testResultsSummary?: string | null): Promise<string | null> => {
  // This endpoint returns plain text
   try {
    // Using fetchApi for consistency, but note it's set up to parse JSON by default for errors.
    // The special handling for this endpoint in fetchApi should manage text response.
    const result = await fetchApi<string>('/symptom-checker/doctor-notes', { symptoms, provisionalDiagnosis, patientProfile, testResultsSummary });
    return result || "Error: Could not generate doctor notes at this time (API call failed).";
  } catch (error) {
    console.error("Network or other error calling /symptom-checker/doctor-notes from service:", error);
    return "Error: Could not connect to generate doctor notes.";
  }
};

export const generatePrescriptionKeywords = async (provisionalDiagnosis: string, currentDoctorSummary: string): Promise<string[] | null> => {
  const result = await fetchApi<string[]>('/prescription/keywords', { provisionalDiagnosis, currentDoctorSummary });
  return result || []; // Fallback to empty array
};

export const generateDoctorNoteSuggestions = async (currentNote: string, provisionalDiagnosis: string, patientProfile?: PatientProfile): Promise<DoctorNoteSuggestion[] | null> => {
  const result = await fetchApi<DoctorNoteSuggestion[]>('/doctor-assist/note-suggestions', { currentNote, provisionalDiagnosis, patientProfile });
  return result || []; // Fallback to empty array
};

export const generateDifferentialDiagnoses = async (patientSymptoms: string, provisionalDiagnosis: string, doctorInitialNotes: string, patientProfile?: PatientProfile): Promise<DDxItem[] | null> => {
  const result = await fetchApi<DDxItem[]>('/doctor-assist/ddx', { patientSymptoms, provisionalDiagnosis, doctorInitialNotes, patientProfile });
  return result || null; // Or an empty array if that's preferred: []
};

export const suggestActionsForDDx = async (selectedDDx: string, patientProfile?: PatientProfile): Promise<DDxActionSuggestion | null> => {
  const result = await fetchApi<DDxActionSuggestion>('/doctor-assist/ddx-actions', { selectedDDx, patientProfile });
  return result || { suggestedMedications: [], suggestedTests: [] }; // Fallback to empty structure
};

export const generatePrescriptionWithEducation = async (provisionalDiagnosis: string, doctorSummaryForPrescription: string, doctorName?: string, clinicAddress?: string, clinicLicense?: string): Promise<Prescription | null> => {
  const result = await fetchApi<Prescription>('/prescription/generate-full', { provisionalDiagnosis, doctorSummaryForPrescription, doctorName, clinicAddress, clinicLicense });
  return result || null; // Fallback to null
};
