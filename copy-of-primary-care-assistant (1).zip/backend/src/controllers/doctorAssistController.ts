import { Request, Response, NextFunction } from 'express';
import { ParamsDictionary, Query } from 'express-serve-static-core';
import * as aiService from '../services/geminiService';
import { 
    PatientProfile,
    DoctorNoteSuggestionsRequest, 
    DoctorNoteSuggestion,
    DifferentialDiagnosesRequest,
    DDxItem,
    DDxActionsRequest,
    DDxActionSuggestion
} from '../types';

const getPatientProfileForRequest = async (profileData?: PatientProfile): Promise<PatientProfile | undefined> => {
    if (!profileData) return undefined;
    return profileData;
};

export const handleGenerateDoctorNoteSuggestions = async (
  req: Request<ParamsDictionary, DoctorNoteSuggestion[] | { error: string }, DoctorNoteSuggestionsRequest, Query>,
  res: Response<DoctorNoteSuggestion[] | { error: string }>
) => {
    try {
        const { currentNote, provisionalDiagnosis, patientProfile: patientProfileInput } = req.body;
        if (!currentNote || !provisionalDiagnosis) {
            return res.status(400).json({ error: "Current note and provisional diagnosis are required." });
        }
        const patientProfile = await getPatientProfileForRequest(patientProfileInput);
        const suggestions = await aiService.generateDoctorNoteSuggestions(currentNote, provisionalDiagnosis, patientProfile);
        if (suggestions) {
            res.status(200).json(suggestions);
        } else {
            // Return empty array as per frontend service fallback
            res.status(200).json([]);
        }
    } catch (error) {
        console.error("Error in handleGenerateDoctorNoteSuggestions:", error);
        res.status(500).json({ error: "An internal server error occurred." });
    }
};

export const handleGenerateDifferentialDiagnoses = async (
  req: Request<ParamsDictionary, DDxItem[] | { error: string }, DifferentialDiagnosesRequest, Query>,
  res: Response<DDxItem[] | { error: string }>
) => {
    try {
        const { patientSymptoms, provisionalDiagnosis, doctorInitialNotes, patientProfile: patientProfileInput } = req.body;
        if (!patientSymptoms || !provisionalDiagnosis || !doctorInitialNotes) {
            return res.status(400).json({ error: "Patient symptoms, provisional diagnosis, and doctor's initial notes are required." });
        }
        const patientProfile = await getPatientProfileForRequest(patientProfileInput);
        const ddxItems = await aiService.generateDifferentialDiagnoses(patientSymptoms, provisionalDiagnosis, doctorInitialNotes, patientProfile);
        if (ddxItems) {
            res.status(200).json(ddxItems);
        } else {
            res.status(500).json({ error: "Failed to generate differential diagnoses." }); // Consistent error message
        }
    } catch (error) {
        console.error("Error in handleGenerateDifferentialDiagnoses:", error);
        res.status(500).json({ error: "An internal server error occurred." });
    }
};

export const handleSuggestActionsForDDx = async (
  req: Request<ParamsDictionary, DDxActionSuggestion | { error: string }, DDxActionsRequest, Query>,
  res: Response<DDxActionSuggestion | { error: string }>
) => {
    try {
        const { selectedDDx, patientProfile: patientProfileInput } = req.body;
        if (!selectedDDx) {
            return res.status(400).json({ error: "Selected DDx condition is required." });
        }
        const patientProfile = await getPatientProfileForRequest(patientProfileInput);
        const ddxActions = await aiService.suggestActionsForDDx(selectedDDx, patientProfile);
        if (ddxActions) {
            res.status(200).json(ddxActions);
        } else {
             // Return empty object as per frontend service fallback
            res.status(200).json({ suggestedMedications: [], suggestedTests: [] });
        }
    } catch (error) {
        console.error("Error in handleSuggestActionsForDDx:", error);
        res.status(500).json({ error: "An internal server error occurred." });
    }
};
