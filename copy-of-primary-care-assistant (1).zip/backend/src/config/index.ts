
import dotenv from 'dotenv';

dotenv.config();

export const config = {
  port: process.env.PORT || '3001',
  geminiApiKey: process.env.API_KEY,
  logLevel: process.env.LOG_LEVEL || 'info',
  // databaseUrl: process.env.DATABASE_URL, // Uncomment when DB is integrated
};

if (!config.geminiApiKey) {
  console.warn("CRITICAL WARNING: API_KEY for Gemini is not set in environment variables. AI functionalities will fail.");
}
