import { Router } from 'express';
import * as doctorAssistController from '../controllers/doctorAssistController';

const router = Router();

router.post('/note-suggestions', doctorAssistController.handleGenerateDoctorNoteSuggestions);
router.post('/ddx', doctorAssistController.handleGenerateDifferentialDiagnoses);
router.post('/ddx-actions', doctorAssistController.handleSuggestActionsForDDx);

export default router;