import express, { Express, Request, Response, NextFunction } from 'express';
import cors from 'cors';
import { config } from './config';
import symptomCheckerRoutes from './routes/symptomCheckerRoutes';
import prescriptionRoutes from './routes/prescriptionRoutes';
import doctorAssistRoutes from './routes/doctorAssistRoutes'; 
import marketplaceRoutes from './routes/marketplaceRoutes'; // New
import orderRoutes from './routes/orderRoutes'; // New
import configRoutes from './routes/configRoutes'; // New

const app: Express = express();
const port = config.port;

// Middleware
app.use(cors()); 
app.use(express.json()); 
app.use(express.urlencoded({ extended: true })); 

// Basic Logging Middleware
app.use((req: Request, res: Response, next: NextFunction) => {
  if (config.logLevel === 'debug' || config.logLevel === 'info') {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
  }
  next();
});

// API Routes
app.use('/api/symptom-checker', symptomCheckerRoutes);
app.use('/api/prescription', prescriptionRoutes);
app.use('/api/doctor-assist', doctorAssistRoutes);
app.use('/api/marketplace', marketplaceRoutes); // New
app.use('/api/orders', orderRoutes); // New
app.use('/api/config', configRoutes); // New


// Root Endpoint
app.get('/', (req: Request, res: Response) => {
  res.send('Primary Care AI Assistant API is running!');
});

// Global Error Handler
app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
  console.error("Unhandled error:", err.stack);
  if (res.headersSent) { // Important check
    return next(err);
  }
  res.status(500).json({ error: 'Something went wrong!', message: err.message });
});

// Start Server
app.listen(port, () => {
  console.log(`Backend server is running on http://localhost:${port}`);
  if (!config.geminiApiKey) {
      console.warn("***************************************************************************");
      console.warn("WARNING: GEMINI API KEY IS NOT SET in .env file.");
      console.warn("The AI functionalities of this API will not work without a valid API_KEY.");
      console.warn("Please create a .env file from .env.example and add your API_KEY.");
      console.warn("***************************************************************************");
  } else {
      console.log("Gemini API Key found. AI services should be operational.");
  }
});
